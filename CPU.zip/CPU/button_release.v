// =============================================================================
// button_release.v - sincroniza o botão (ativo em 0), faz debounce e gera um
// pulso de 1 ciclo quando o botão é SOLTO (0 -> 1 estável).
// =============================================================================
module button_release #(
    parameter DEBOUNCE_CYCLES = 500000       // ~10 ms @ 50 MHz (use 2 em simulação)
)(
    input  wire clk,
    input  wire rst_n,
    input  wire key_n,
    output reg  released
);
    reg [1:0]  sync;
    reg        stable;
    reg [23:0] cnt;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            sync     <= 2'b11;
            stable   <= 1'b1;
            cnt      <= 24'd0;
            released <= 1'b0;
        end else begin
            sync     <= {sync[0], key_n};
            released <= 1'b0;

            if (sync[1] == stable) begin
                cnt <= 24'd0;
            end else if (cnt == DEBOUNCE_CYCLES - 1) begin
                cnt    <= 24'd0;
                stable <= sync[1];
                if (sync[1]) released <= 1'b1;   // transição 0 -> 1 = soltou
            end else begin
                cnt <= cnt + 24'd1;
            end
        end
    end
endmodule
