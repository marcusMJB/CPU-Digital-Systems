// =============================================================================
// module_mini_cpu.v  -  Mini_CPU: UNIDADE DE CONTROLE + integração
//
// Instancia os módulos já existentes do projeto:
//   memory          (memory.v)             RAM 16x16, porta única, leitura com 1 ciclo de latência
//   module_alu      (modulo_alu.v)         ULA (valor1, valor2, imm, operacao -> resultado)
//   lcd_controller  (lcd_controller (1).v) driver do LCD (power / update / busy)
//   button_release  (button_release.v)     botão solto + debounce
//
// Fluxo da FSM:
//   OFF -> CLR_ON -> IDLE -> FETCH -> RD1 -> RD2 -> RD3 -> EXEC -> WB
//       -> (CLEAR ? CLR_INS : -) -> SHOW_WAIT -> SHOW_PULSE -> IDLE
//   (botão Ligar solto em qualquer estado: CLR_OFF -> OFF)
//
// Formato dos 18 switches (campos alinhados à esquerda, opcode SEMPRE em [17:15]):
//   Tipo 1 (ADD, SUB)        : [17:15] op | [14:11] dest | [10:7] src1 | [6:3] src2
//   Tipo 2 (ADDI, SUBI, MUL) : [17:15] op | [14:11] dest | [10:7] src1 | [6] sinal | [5:0] imm
//   Tipo 3 (LOAD)            : [17:15] op | [14:11] dest | [10] sinal | [9:4] imm
//   CLEAR                    : [17:15] op
//   DISPLAY                  : [17:15] op | [14:11] registrador a exibir
// (se precisar mudar as posições, edite só o bloco "Decodificação de campos")
// =============================================================================
module module_mini_cpu #(
    parameter DEBOUNCE_CYCLES = 500000      // ~10 ms @ 50 MHz (use 2 em simulação)
)(
    input  wire        clk,                 // 50 MHz
    input  wire        rst_n,                 // reset assíncrono, ativo em 0 
    input  wire        key_power_n,         // botão Ligar/Desligar (KEY, ativo em 0)
    input  wire        key_send_n,          // botão Enviar          (KEY, ativo em 0)
    input  wire [17:0] sw,                  // SW[17:0]

    output wire [7:0]  lcd_data,
    output wire        lcd_rs,
    output wire        lcd_rw,
    output wire        lcd_e
);
    
	 wire rst = ~rst_n;


    // -------------------------------------------------------------------------
    // Opcodes
    // -------------------------------------------------------------------------
    localparam [2:0] OP_LOAD    = 3'b000,
                     OP_ADD     = 3'b001,
                     OP_ADDI    = 3'b010,
                     OP_SUB     = 3'b011,
                     OP_SUBI    = 3'b100,
                     OP_MUL     = 3'b101,
                     OP_CLEAR   = 3'b110,
                     OP_DISPLAY = 3'b111;

    // -------------------------------------------------------------------------
    // Estados
    // -------------------------------------------------------------------------
    localparam [3:0]
        S_OFF        = 4'd0,    // desligado
        S_CLR_ON     = 4'd1,    // ao ligar: zera os 16 registradores
        S_CLR_OFF    = 4'd2,    // ao desligar: zera os 16 registradores
        S_IDLE       = 4'd3,    // ligado, esperando o botão Enviar
        S_FETCH      = 4'd4,    // busca: captura os switches
        S_RD1        = 4'd5,    // coloca o endereço do 1º operando
        S_RD2        = 4'd6,    // captura operando 1 / coloca endereço do 2º
        S_RD3        = 4'd7,    // captura operando 2
        S_EXEC       = 4'd8,    // ULA calcula
        S_WB         = 4'd9,    // store: escreve o resultado no destino
        S_CLR_INS    = 4'd10,   // instrução CLEAR: zera os 16 registradores
        S_SHOW_WAIT  = 4'd11,   // espera o LCD ficar livre (busy = 0)
        S_SHOW_PULSE = 4'd12;   // pulso de update para o LCD

    reg [3:0] state, next_state;

    // -------------------------------------------------------------------------
    // Botões (ação somente quando SOLTOS)
    // -------------------------------------------------------------------------
    wire power_rel, send_rel;

    button_release #(.DEBOUNCE_CYCLES(DEBOUNCE_CYCLES)) u_btn_power (
        .clk(clk), .rst_n(~rst), .key_n(key_power_n), .released(power_rel)
    );
    button_release #(.DEBOUNCE_CYCLES(DEBOUNCE_CYCLES)) u_btn_send (
        .clk(clk), .rst_n(~rst), .key_n(key_send_n), .released(send_rel)
    );

    // -------------------------------------------------------------------------
    // Registradores do caminho de dados
    // -------------------------------------------------------------------------
    reg               sys_on;           // 1 = sistema ligado (vai para o LCD)
    reg  [17:0]       ir;               // instrução capturada
    reg signed [15:0] a_q;              // operando 1 (lido da memória)
    reg signed [15:0] b_q;              // operando 2 (lido da memória)
    reg signed [15:0] res_q;            // resultado
    reg  [3:0]        clr_cnt;          // contador do laço de zerar registradores

    // -------------------------------------------------------------------------
    // Decodificação de campos (combinacional a partir de ir)
    // -------------------------------------------------------------------------
    wire [2:0] op     = ir[17:15];
    wire [3:0] f_dest = ir[14:11];      // destino (ou registrador do DISPLAY)
    wire [3:0] f_src1 = ir[10:7];
    wire [3:0] f_src2 = ir[6:3];

    wire       sign_i = ir[6];          // imediato Tipo 2 (ADDI, SUBI, MUL)
    wire [5:0] mag_i  = ir[5:0];
    wire       sign_l = ir[10];         // imediato Tipo 3 (LOAD)
    wire [5:0] mag_l  = ir[9:4];

    wire [6:0] imm7_i = sign_i ? (~{1'b0, mag_i} + 7'd1) : {1'b0, mag_i};
    wire [6:0] imm7_l = sign_l ? (~{1'b0, mag_l} + 7'd1) : {1'b0, mag_l};
    wire [6:0] imm7   = (op == OP_LOAD) ? imm7_l : imm7_i;          // sinal + módulo -> complemento de 2
    wire signed [15:0] imm16 = {{9{imm7[6]}}, imm7};

    wire is_clear    = (op == OP_CLEAR);
    wire is_display  = (op == OP_DISPLAY);
    wire writes_back = ~(is_clear | is_display);                    // LOAD/ADD/ADDI/SUB/SUBI/MUL

    wire [3:0] ra1 = is_display ? f_dest : f_src1;                  // 1º endereço de leitura

    wire in_clr   = (state == S_CLR_ON) | (state == S_CLR_OFF) | (state == S_CLR_INS);
    wire clr_last = (clr_cnt == 4'd15);
    wire is_off_state = (state == S_OFF) | (state == S_CLR_OFF);

    // -------------------------------------------------------------------------
    // Memória, ULA e LCD
    // -------------------------------------------------------------------------
    reg  [3:0]  mem_addr;
    reg  [15:0] mem_data;
    reg         mem_we;
    wire [15:0] mem_q;

    memory u_mem (
        .data (mem_data),
        .addr (mem_addr),
        .we   (mem_we),
        .clk  (clk),
        .q    (mem_q)
    );

    wire signed [15:0] alu_res;

    module_alu u_alu (
        .valor1    (a_q),
        .valor2    (b_q),
        .imm       (imm7),
        .operacao  (op),
        .resultado (alu_res)
    );

    reg         lcd_update;
    wire        lcd_busy;
    wire signed [15:0] lcd_value = is_display ? a_q : res_q;

    lcd_controller u_lcd (
        .clk      (clk),
        .rst      (rst),
        .power    (sys_on),
        .update   (lcd_update),
        .op       (op),
        .dest     (f_dest),
        .value    (lcd_value),
        .busy     (lcd_busy),
        .lcd_data (lcd_data),
        .lcd_rs   (lcd_rs),
        .lcd_rw   (lcd_rw),
        .lcd_e    (lcd_e)
    );

    // =========================================================================
    // 1) BLOCO SEQUENCIAL: registrador de estado
    // =========================================================================
    always @(posedge clk or posedge rst) begin
        if (rst) state <= S_OFF;
        else     state <= next_state;
    end

    // =========================================================================
    // 1b) BLOCO SEQUENCIAL: caminho de dados
    // =========================================================================
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            sys_on  <= 1'b0;
            ir      <= 18'd0;
            a_q     <= 16'sd0;
            b_q     <= 16'sd0;
            res_q   <= 16'sd0;
            clr_cnt <= 4'd0;
        end else if (power_rel) begin
            sys_on  <= is_off_state;    // desligado -> liga; ligado -> desliga
            clr_cnt <= 4'd0;
        end else begin
            if (in_clr) clr_cnt <= clr_cnt + 4'd1;   // 15 -> 0 sozinho ao terminar

            case (state)
                S_FETCH: ir    <= sw;                                   // busca
                S_RD2:   a_q   <= $signed(mem_q);                       // q = R[endereço de RD1]
                S_RD3:   b_q   <= $signed(mem_q);                       // q = R[endereço de RD2]
                S_EXEC:  res_q <= (op == OP_LOAD) ? imm16 : alu_res;    // LOAD não passa pela ULA
                default: ;
            endcase
        end
    end

    // =========================================================================
    // 2) BLOCO COMBINACIONAL: próximo estado
    // =========================================================================
    always @(*) begin
        next_state = state;

        if (power_rel) begin
            // Ligar solto: alterna ligado/desligado em qualquer estado
            next_state = is_off_state ? S_CLR_ON : S_CLR_OFF;
        end else begin
            case (state)
                S_OFF:        next_state = S_OFF;
                S_CLR_ON:     if (clr_last) next_state = S_IDLE;
                S_CLR_OFF:    if (clr_last) next_state = S_OFF;
                S_IDLE:       if (send_rel) next_state = S_FETCH;
                S_FETCH:      next_state = S_RD1;
                S_RD1:        next_state = S_RD2;
                S_RD2:        next_state = S_RD3;
                S_RD3:        next_state = S_EXEC;
                S_EXEC:       next_state = S_WB;
                S_WB:         next_state = is_clear ? S_CLR_INS : S_SHOW_WAIT;
                S_CLR_INS:    if (clr_last) next_state = S_SHOW_WAIT;
                S_SHOW_WAIT:  if (!lcd_busy) next_state = S_SHOW_PULSE;
                S_SHOW_PULSE: next_state = S_IDLE;
                default:      next_state = S_OFF;
            endcase
        end
    end

    // =========================================================================
    // 3) BLOCO COMBINACIONAL: saídas (Moore) - memória e LCD
    // =========================================================================
    always @(*) begin
        mem_addr   = f_dest;
        mem_data   = res_q;
        mem_we     = 1'b0;
        lcd_update = 1'b0;

        case (state)
            S_CLR_ON, S_CLR_OFF, S_CLR_INS: begin   // escreve 0 nos 16 registradores
                mem_addr = clr_cnt;
                mem_data = 16'd0;
                mem_we   = 1'b1;
            end
            S_RD1:        mem_addr = ra1;           // operando 1 (ou reg. do DISPLAY)
            S_RD2:        mem_addr = f_src2;        // operando 2
            S_WB:         mem_we   = writes_back;   // grava em f_dest
            S_SHOW_PULSE: lcd_update = 1'b1;        // 1 ciclo, com busy = 0
            default: ;
        endcase
    end

endmodule
